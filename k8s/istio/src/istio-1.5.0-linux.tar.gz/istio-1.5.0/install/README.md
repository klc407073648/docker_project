# Istio installation

This directory contains the default Istio installation configuration in several
different flavors. Also contained is the script for updating it.
