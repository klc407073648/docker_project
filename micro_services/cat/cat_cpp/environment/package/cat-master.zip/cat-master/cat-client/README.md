# Cat Client Java

该客户端模块以后不再维护，目前仅做服务端的依赖模块。下个大版本更新计划移除。

[新版Java客户端](../lib/java/README.md)

多语言客户端（C/C++、Node.js、Python、Golang）请参考 lib 模块。

